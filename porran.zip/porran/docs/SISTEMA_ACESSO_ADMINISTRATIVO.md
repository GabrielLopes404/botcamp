# Sistema de Acesso, Níveis e Autenticação Administrativa

**Data:** 07 de Novembro de 2025  
**Sistema:** LUCREI - Gestão Financeira SaaS  
**Versão:** 1.0

---

## 📋 Índice

1. [Visão Geral](#visão-geral)
2. [Níveis de Acesso](#níveis-de-acesso)
3. [Autenticação](#autenticação)
4. [Login Administrativo](#login-administrativo)
5. [Permissões e Restrições](#permissões-e-restrições)
6. [Gestão de Usuários](#gestão-de-usuários)
7. [Segurança](#segurança)
8. [Endpoints da API](#endpoints-da-api)
9. [Exemplos Práticos](#exemplos-práticos)

---

## 🔍 Visão Geral

O LUCREI implementa um sistema de controle de acesso baseado em funções (RBAC - Role-Based Access Control) com três níveis hierárquicos de permissões. O sistema garante isolamento de dados por organização e implementa múltiplas camadas de segurança.

### Arquitetura de Autenticação

- **Estratégia:** Session-based authentication com Passport.js
- **Armazenamento de Sessões:** PostgreSQL (via connect-pg-simple)
- **Hash de Senhas:** bcrypt com 12 rounds
- **Proteção CSRF:** Tokens em todas as rotas mutáveis
- **Rate Limiting:** Proteção contra força bruta

---

## 👥 Níveis de Acesso

### 1. OWNER (Proprietário)

**Descrição:** Nível mais alto de acesso no sistema. É automaticamente atribuído ao primeiro usuário que cria uma organização.

**Características:**
- Controle total sobre a organização
- Único que pode deletar a organização
- Pode transferir ownership para outro usuário
- Gerencia todos os aspectos administrativos
- Tem acesso ao painel administrativo

**Criação:**
- Atribuído automaticamente ao criar uma conta via `/register`
- Apenas um OWNER por organização (pode ser transferido)

**Permissões Exclusivas:**
- Deletar organização
- Transferir ownership
- Gerenciar planos e assinaturas

---

### 2. ADMIN (Administrador)

**Descrição:** Segundo nível de acesso com permissões administrativas amplas.

**Características:**
- Permissões administrativas completas
- Pode gerenciar usuários, transações, relatórios
- Pode convidar e remover usuários
- Tem acesso ao painel administrativo
- Não pode alterar configurações críticas da organização

**Criação:**
- Promovido pelo OWNER via endpoint `/api/users/:id/promote`
- Múltiplos ADMINs podem existir na mesma organização

**Permissões:**
- Criar, editar, deletar transações
- Gerenciar clientes
- Acessar todos os relatórios
- Convidar novos usuários
- Remover usuários CUSTOMER
- Configurar categorias, centros de custo, tags
- Gerenciar contas bancárias

**Restrições:**
- Não pode deletar a organização
- Não pode remover o OWNER
- Não pode alterar configurações de pagamento

---

### 3. CUSTOMER (Cliente/Usuário)

**Descrição:** Nível básico de acesso para usuários regulares.

**Características:**
- Permissões limitadas ao seu próprio trabalho
- Pode gerenciar suas próprias transações
- Visualização de relatórios pessoais
- Sem acesso administrativo

**Criação:**
- Convidado por OWNER ou ADMIN
- Padrão para novos usuários convidados

**Permissões:**
- Criar e editar suas próprias transações
- Ver seus próprios relatórios
- Gerenciar seu perfil
- Exportar seus próprios dados

**Restrições:**
- Não pode convidar outros usuários
- Não pode acessar dados de outros usuários
- Não pode alterar configurações da organização
- Não pode acessar o painel administrativo

---

## 🔐 Autenticação

### Login Regular (`/login`)

**Endpoint:** `POST /api/auth/login`

**Fluxo:**
1. Usuário submete email e senha
2. Backend valida credenciais com bcrypt
3. Verifica se email foi verificado
4. Cria sessão no PostgreSQL
5. Retorna dados do usuário (sem senha)

**Requisitos:**
- Email verificado
- Senha válida
- Conta ativa

```json
// Request
POST /api/auth/login
{
  "email": "usuario@empresa.com",
  "password": "SenhaSegura123!"
}

// Response (Success)
{
  "user": {
    "id": "uuid",
    "username": "usuario",
    "email": "usuario@empresa.com",
    "name": "Nome do Usuário",
    "organizationId": "org-uuid",
    "role": "CUSTOMER",
    "emailVerified": true
  }
}
```

---

### Login Administrativo (`/admin/login`)

**Endpoint:** `POST /api/auth/admin/login`

**Descrição:** Rota especializada para acesso administrativo que verifica o nível de permissão do usuário.

**Fluxo:**
1. Usuário submete email e senha
2. Backend valida credenciais
3. **Verifica se role é ADMIN ou OWNER**
4. Se não for admin: retorna erro 403
5. Se for admin: cria sessão e permite acesso

**Requisitos:**
- Email verificado
- Senha válida
- Role = ADMIN ou OWNER

**Interface:**
- Link "Você trabalha aqui?" na página de login regular
- Página dedicada em `/admin/login`
- Visual distintivo com cor vermelha
- Aviso de que tentativas são registradas

```json
// Request
POST /api/auth/admin/login
{
  "email": "admin@empresa.com",
  "password": "AdminPass123!"
}

// Response (Success - ADMIN ou OWNER)
{
  "user": {
    "id": "uuid",
    "username": "admin",
    "email": "admin@empresa.com",
    "name": "Administrador",
    "organizationId": "org-uuid",
    "role": "ADMIN",
    "emailVerified": true
  },
  "message": "Login administrativo realizado com sucesso"
}

// Response (Error - CUSTOMER tentando acessar)
{
  "message": "Acesso negado. Apenas administradores podem acessar esta área."
}
```

---

## 🛡️ Permissões e Restrições

### Matriz de Permissões

| Recurso | CUSTOMER | ADMIN | OWNER |
|---------|----------|-------|-------|
| Ver próprias transações | ✅ | ✅ | ✅ |
| Ver todas transações | ❌ | ✅ | ✅ |
| Criar transações | ✅ | ✅ | ✅ |
| Editar transações | ✅ (próprias) | ✅ (todas) | ✅ (todas) |
| Deletar transações | ✅ (próprias) | ✅ (todas) | ✅ (todas) |
| Gerenciar clientes | ❌ | ✅ | ✅ |
| Ver relatórios | ✅ (próprios) | ✅ (todos) | ✅ (todos) |
| Exportar dados | ✅ (próprios) | ✅ (todos) | ✅ (todos) |
| Convidar usuários | ❌ | ✅ | ✅ |
| Remover usuários | ❌ | ✅ (exceto OWNER) | ✅ (todos) |
| Promover usuários | ❌ | ❌ | ✅ |
| Rebaixar usuários | ❌ | ❌ | ✅ |
| Configurar organização | ❌ | ⚠️ (parcial) | ✅ |
| Gerenciar assinaturas | ❌ | ❌ | ✅ |
| Deletar organização | ❌ | ❌ | ✅ |
| Acesso admin login | ❌ | ✅ | ✅ |

**Legenda:**  
✅ = Permitido  
❌ = Negado  
⚠️ = Parcialmente permitido

---

## 👤 Gestão de Usuários

### Como Criar um Administrador

#### Opção 1: Promover Usuário Existente

```bash
# Via API (requer autenticação como OWNER)
POST /api/users/:userId/promote
Headers:
  X-CSRF-Token: {token}
  Cookie: session=...
```

#### Opção 2: Criar Conta e Promover

1. Usuário se registra normalmente em `/register`
2. OWNER acessa painel de gerenciamento
3. OWNER promove o usuário para ADMIN

### Como Rebaixar um Administrador

```bash
# Via API (requer autenticação como OWNER)
POST /api/users/:userId/demote
Headers:
  X-CSRF-Token: {token}
  Cookie: session=...
```

### Convidar Novos Usuários

ADMINs e OWNERs podem convidar usuários:

1. Acessar painel de gerenciamento de usuários
2. Clicar em "Convidar Usuário"
3. Inserir email do novo usuário
4. Sistema envia email de convite
5. Usuário cria senha e completa registro

---

## 🔒 Segurança

### Camadas de Proteção

1. **Autenticação de Sessão**
   - Sessões armazenadas no PostgreSQL
   - Cookies HttpOnly e Secure (produção)
   - SameSite: Strict

2. **Proteção CSRF**
   - Token CSRF em todas rotas POST/PUT/DELETE
   - Validação automática via middleware

3. **Rate Limiting**
   - Login: 5 tentativas / 15 minutos
   - Registro: 3 tentativas / hora
   - Reset de senha: 3 tentativas / hora

4. **Password Hashing**
   - bcrypt com 12 rounds
   - Sem armazenamento de senha em texto plano

5. **Verificação de Email**
   - Registro requer verificação de email
   - Login bloqueado até verificação

6. **Isolamento de Dados**
   - Todas queries filtradas por `organizationId`
   - Impossível acessar dados de outras organizações

7. **Auditoria**
   - Registro de atividades administrativas
   - Logs de tentativas de acesso
   - Rastreamento de alterações

---

## 🌐 Endpoints da API

### Autenticação

```bash
# Login Regular
POST /api/auth/login
Body: { "email": "...", "password": "..." }

# Login Administrativo (ADMIN/OWNER apenas)
POST /api/auth/admin/login
Body: { "email": "...", "password": "..." }

# Logout
POST /api/auth/logout

# Verificar Usuário Atual
GET /api/auth/me

# Esqueci Minha Senha
POST /api/auth/forgot-password
Body: { "email": "..." }

# Resetar Senha
POST /api/auth/reset-password
Body: { "token": "...", "password": "..." }
```

### Gerenciamento de Usuários

```bash
# Listar Usuários da Organização (ADMIN/OWNER)
GET /api/users

# Promover Usuário para ADMIN (OWNER apenas)
POST /api/users/:id/promote

# Rebaixar ADMIN para CUSTOMER (OWNER apenas)
POST /api/users/:id/demote

# Remover Usuário (ADMIN/OWNER)
DELETE /api/users/:id

# Convidar Usuário (ADMIN/OWNER)
POST /api/users/invite
Body: { "email": "..." }
```

### Organizações

```bash
# Ver Organização Atual
GET /api/organizations/current

# Atualizar Organização (ADMIN/OWNER)
PUT /api/organizations/current
Body: { "name": "...", "email": "...", ... }
```

---

## 💡 Exemplos Práticos

### Exemplo 1: Primeiro Acesso como OWNER

```javascript
// 1. Criar conta (torna-se OWNER automaticamente)
const response = await fetch('/api/auth/register', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    username: 'empresa',
    email: 'contato@empresa.com',
    password: 'SenhaSegura123!',
    name: 'Empresa LTDA'
  })
});

// 2. Verificar email (clicar no link recebido)

// 3. Fazer login
const loginResponse = await fetch('/api/auth/login', {
  method: 'POST',
  headers: { 
    'Content-Type': 'application/json',
    'X-CSRF-Token': csrfToken
  },
  credentials: 'include',
  body: JSON.stringify({
    email: 'contato@empresa.com',
    password: 'SenhaSegura123!'
  })
});

// Agora tem acesso completo como OWNER
```

### Exemplo 2: Criar um Administrador

```javascript
// Como OWNER, promover usuário existente
const promoteResponse = await fetch('/api/users/user-id-aqui/promote', {
  method: 'POST',
  headers: { 'X-CSRF-Token': csrfToken },
  credentials: 'include'
});

// Usuário agora pode fazer login via /admin/login
```

### Exemplo 3: Login Administrativo

```javascript
// Fazer login como admin
const adminLoginResponse = await fetch('/api/auth/admin/login', {
  method: 'POST',
  headers: { 
    'Content-Type': 'application/json',
    'X-CSRF-Token': csrfToken
  },
  credentials: 'include',
  body: JSON.stringify({
    email: 'admin@empresa.com',
    password: 'AdminPass123!'
  })
});

if (adminLoginResponse.ok) {
  // Login bem-sucedido
  const data = await adminLoginResponse.json();
  console.log('Logado como:', data.user.role); // "ADMIN" ou "OWNER"
} else if (adminLoginResponse.status === 403) {
  // Usuário não é admin
  console.error('Acesso negado - requer nível ADMIN ou OWNER');
}
```

---

## 📊 Resumo do Sistema

### Pontos Fortes

✅ **RBAC Implementado:** Três níveis claros de permissão  
✅ **Isolamento de Dados:** Por organização  
✅ **Segurança Robusta:** Múltiplas camadas de proteção  
✅ **Login Administrativo:** Rota dedicada com validação  
✅ **Auditoria:** Registro de atividades  
✅ **Escalável:** Suporta múltiplos usuários e organizações  

### Melhorias Futuras Sugeridas

- Implementar 2FA para administradores
- Adicionar logs de auditoria mais detalhados
- Sistema de convites com expiração
- Painel de gerenciamento de usuários no frontend
- Relatórios de atividades administrativas
- Notificações de login administrativo

---

## 🆘 Suporte e Troubleshooting

### Problema: Usuário não consegue acessar /admin/login

**Solução:** Verificar role do usuário
```bash
GET /api/auth/me
```
Se role for "CUSTOMER", promover para "ADMIN" ou "OWNER"

### Problema: CSRF Token inválido

**Solução:** Obter novo token
```bash
GET /api/csrf-token
```

### Problema: Sessão expira muito rápido

**Solução:** Configurar tempo de expiração em `server/routes.ts`:
```javascript
maxAge: 1000 * 60 * 60 * 24 * 7 // 7 dias
```

---

## 📝 Conclusão

O sistema LUCREI implementa um controle de acesso robusto e seguro com três níveis de permissão claramente definidos. O login administrativo garante que apenas usuários com as permissões adequadas (ADMIN ou OWNER) possam acessar áreas sensíveis do sistema.

Todas as operações são auditadas e protegidas por múltiplas camadas de segurança, incluindo CSRF, rate limiting, hash de senhas e isolamento de dados por organização.

**Documentação elaborada em:** 07/11/2025  
**Última atualização:** 07/11/2025
