import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Check } from "lucide-react";
import { motion } from "framer-motion";

export default function IntegracoesPage() {
  const [, setLocation] = useLocation();

  const integrations = [
    {
      name: "Stripe",
      category: "Pagamentos",
      description: "Integração completa para receber pagamentos online",
      status: "Disponível",
      logo: "💳"
    },
    {
      name: "Bancos Brasileiros",
      category: "Bancário",
      description: "Importação automática de extratos via OFX",
      status: "Disponível",
      logo: "🏦"
    },
    {
      name: "Resend",
      category: "Email",
      description: "Envio de emails transacionais e notificações",
      status: "Disponível",
      logo: "✉️"
    },
    {
      name: "API REST",
      category: "Desenvolvimento",
      description: "API completa para integrações customizadas",
      status: "Disponível",
      logo: "🔌"
    },
    {
      name: "Webhooks",
      category: "Desenvolvimento",
      description: "Notificações em tempo real de eventos",
      status: "Disponível",
      logo: "🔔"
    },
    {
      name: "Excel / CSV",
      category: "Importação",
      description: "Importação e exportação de dados em massa",
      status: "Disponível",
      logo: "📊"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-4 md:px-8 py-12">
        <Button 
          variant="ghost" 
          onClick={() => setLocation("/")} 
          className="mb-8"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Voltar
        </Button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h1 className="text-2xl md:text-4xl sm:text-xl md:text-3xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/80 bg-clip-text text-transparent">
            Integrações
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Conecte o LUCREI com suas ferramentas favoritas
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-6">
          {integrations.map((integration, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="h-full hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="text-2xl md:text-4xl">{integration.logo}</div>
                    <Badge variant="secondary">{integration.status}</Badge>
                  </div>
                  <h3 className="font-semibold text-lg mb-1">{integration.name}</h3>
                  <p className="text-sm text-muted-foreground mb-3">{integration.category}</p>
                  <p className="text-sm">{integration.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="mt-16"
        >
          <Card className="bg-gradient-to-r from-primary/10 to-primary/10 border-primary/20">
            <CardContent className="p-4 md:p-8 text-center">
              <h2 className="text-2xl font-bold mb-4">Precisa de uma integração customizada?</h2>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                Nossa API REST completa permite que você crie integrações personalizadas para qualquer sistema.
              </p>
              <div className="flex gap-4 justify-center">
                <Button 
                  onClick={() => setLocation("/api-docs")}
                  variant="outline"
                >
                  Ver Documentação da API
                </Button>
                <Button 
                  onClick={() => setLocation("/contato")}
                  className="bg-gradient-to-r from-primary to-primary/80"
                >
                  Falar com Especialista
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
