import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { PageContainer } from "@/components/PageContainer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Crown, DollarSign, Users, Activity, Plus, Edit, Trash2, Shield, ArrowUp, ArrowDown } from "lucide-react";
import { format } from "date-fns";

export default function OwnerDashboardPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [csrfToken, setCsrfToken] = useState("");
  const [planDialogOpen, setPlanDialogOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<any>(null);

  // Buscar CSRF Token
  useEffect(() => {
    fetch("/api/csrf-token", { credentials: "include" })
      .then((res) => res.json())
      .then((data) => setCsrfToken(data.csrfToken))
      .catch((error) => console.error("Failed to fetch CSRF token:", error));
  }, []);

  // Queries
  const { data: plansData } = useQuery({
    queryKey: ["/api/subscription-plans"],
    queryFn: async () => {
      const res = await fetch("/api/subscription-plans", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch plans");
      return res.json();
    },
  });

  const { data: usersData } = useQuery({
    queryKey: ["/api/users"],
    queryFn: async () => {
      const res = await fetch("/api/users", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch users");
      return res.json();
    },
  });

  const { data: auditLogsData } = useQuery({
    queryKey: ["/api/audit-logs"],
    queryFn: async () => {
      const res = await fetch("/api/audit-logs?limit=50", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch audit logs");
      return res.json();
    },
  });

  // Mutations
  const createPlanMutation = useMutation({
    mutationFn: async (planData: any) => {
      const res = await fetch("/api/subscription-plans", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken,
        },
        credentials: "include",
        body: JSON.stringify(planData),
      });
      if (!res.ok) throw new Error("Failed to create plan");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/subscription-plans"] });
      toast({ title: "Sucesso", description: "Plano criado com sucesso" });
      setPlanDialogOpen(false);
    },
  });

  const updatePlanMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      const res = await fetch(`/api/subscription-plans/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken,
        },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to update plan");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/subscription-plans"] });
      toast({ title: "Sucesso", description: "Plano atualizado com sucesso" });
      setPlanDialogOpen(false);
      setEditingPlan(null);
    },
  });

  const promoteUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      const res = await fetch(`/api/users/${userId}/promote`, {
        method: "POST",
        headers: { "X-CSRF-Token": csrfToken },
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to promote user");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({ title: "Sucesso", description: "Usuário promovido para ADMIN" });
    },
  });

  const demoteUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      const res = await fetch(`/api/users/${userId}/demote`, {
        method: "POST",
        headers: { "X-CSRF-Token": csrfToken },
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to demote user");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({ title: "Sucesso", description: "Usuário rebaixado para CUSTOMER" });
    },
  });

  const handleCreatePlan = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const planData = {
      name: formData.get("name"),
      description: formData.get("description"),
      price: formData.get("price"),
      billingPeriod: formData.get("billingPeriod"),
      features: formData.get("features")?.toString().split(",").map(f => f.trim()),
      maxUsers: parseInt(formData.get("maxUsers")?.toString() || "0"),
      maxTransactions: parseInt(formData.get("maxTransactions")?.toString() || "0"),
    };

    if (editingPlan) {
      updatePlanMutation.mutate({ id: editingPlan.id, data: planData });
    } else {
      createPlanMutation.mutate(planData);
    }
  };

  return (
    <PageContainer
      title="Painel do Proprietário"
      description="Controle total sobre o sistema e configurações"
    >
      <div className="grid gap-6">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Planos Ativos</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{plansData?.plans?.filter((p: any) => p.isActive).length || 0}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total de Usuários</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{usersData?.users?.length || 0}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Administradores</CardTitle>
              <Shield className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {usersData?.users?.filter((u: any) => u.role === "ADMIN").length || 0}
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Ações Auditadas</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{auditLogsData?.total || 0}</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="plans" className="space-y-4">
          <TabsList>
            <TabsTrigger value="plans">Planos de Assinatura</TabsTrigger>
            <TabsTrigger value="users">Gerenciar Usuários</TabsTrigger>
            <TabsTrigger value="audit">Logs de Auditoria</TabsTrigger>
          </TabsList>

          <TabsContent value="plans" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Planos de Assinatura</CardTitle>
                    <CardDescription>Gerencie os planos disponíveis do sistema</CardDescription>
                  </div>
                  <Dialog open={planDialogOpen} onOpenChange={setPlanDialogOpen}>
                    <DialogTrigger asChild>
                      <Button onClick={() => setEditingPlan(null)}>
                        <Plus className="h-4 w-4 mr-2" />
                        Novo Plano
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>{editingPlan ? "Editar Plano" : "Criar Novo Plano"}</DialogTitle>
                        <DialogDescription>
                          Configure os detalhes do plano de assinatura
                        </DialogDescription>
                      </DialogHeader>
                      <form onSubmit={handleCreatePlan} className="space-y-4">
                        <div className="grid gap-4 md:grid-cols-2">
                          <div className="space-y-2">
                            <Label htmlFor="name">Nome do Plano</Label>
                            <Input id="name" name="name" defaultValue={editingPlan?.name} required />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="price">Preço (R$)</Label>
                            <Input
                              id="price"
                              name="price"
                              type="number"
                              step="0.01"
                              defaultValue={editingPlan?.price}
                              required
                            />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="description">Descrição</Label>
                          <Textarea
                            id="description"
                            name="description"
                            defaultValue={editingPlan?.description}
                          />
                        </div>
                        <div className="grid gap-4 md:grid-cols-3">
                          <div className="space-y-2">
                            <Label htmlFor="billingPeriod">Período</Label>
                            <select
                              id="billingPeriod"
                              name="billingPeriod"
                              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2"
                              defaultValue={editingPlan?.billingPeriod || "monthly"}
                              required
                            >
                              <option value="monthly">Mensal</option>
                              <option value="yearly">Anual</option>
                            </select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="maxUsers">Máx. Usuários</Label>
                            <Input
                              id="maxUsers"
                              name="maxUsers"
                              type="number"
                              defaultValue={editingPlan?.maxUsers}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="maxTransactions">Máx. Transações</Label>
                            <Input
                              id="maxTransactions"
                              name="maxTransactions"
                              type="number"
                              defaultValue={editingPlan?.maxTransactions}
                            />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="features">Recursos (separados por vírgula)</Label>
                          <Textarea
                            id="features"
                            name="features"
                            placeholder="Dashboard avançado, Relatórios ilimitados, Suporte prioritário"
                            defaultValue={editingPlan?.features?.join(", ")}
                          />
                        </div>
                        <div className="flex justify-end gap-2">
                          <Button type="button" variant="outline" onClick={() => setPlanDialogOpen(false)}>
                            Cancelar
                          </Button>
                          <Button type="submit">
                            {editingPlan ? "Atualizar" : "Criar"} Plano
                          </Button>
                        </div>
                      </form>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Preço</TableHead>
                      <TableHead>Período</TableHead>
                      <TableHead>Limites</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {plansData?.plans?.map((plan: any) => (
                      <TableRow key={plan.id}>
                        <TableCell className="font-medium">{plan.name}</TableCell>
                        <TableCell>R$ {plan.price}</TableCell>
                        <TableCell>
                          {plan.billingPeriod === "monthly" ? "Mensal" : "Anual"}
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {plan.maxUsers} usuários / {plan.maxTransactions} transações
                        </TableCell>
                        <TableCell>
                          <Badge variant={plan.isActive ? "default" : "secondary"}>
                            {plan.isActive ? "Ativo" : "Inativo"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => {
                              setEditingPlan(plan);
                              setPlanDialogOpen(true);
                            }}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Gerenciar Usuários e Administradores</CardTitle>
                <CardDescription>Promova ou rebaixe permissões de usuários</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Função</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {usersData?.users?.map((user: any) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">{user.name || user.username}</TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              user.role === "OWNER"
                                ? "default"
                                : user.role === "ADMIN"
                                ? "secondary"
                                : "outline"
                            }
                          >
                            {user.role === "OWNER" && <Crown className="h-3 w-3 mr-1" />}
                            {user.role}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant={user.emailVerified ? "default" : "outline"}>
                            {user.emailVerified ? "Verificado" : "Não verificado"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {user.role !== "OWNER" && (
                            <div className="flex gap-2">
                              {user.role !== "ADMIN" && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => promoteUserMutation.mutate(user.id)}
                                >
                                  <ArrowUp className="h-4 w-4 mr-1" />
                                  Promover
                                </Button>
                              )}
                              {user.role === "ADMIN" && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => demoteUserMutation.mutate(user.id)}
                                >
                                  <ArrowDown className="h-4 w-4 mr-1" />
                                  Rebaixar
                                </Button>
                              )}
                            </div>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="audit" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Logs de Auditoria</CardTitle>
                <CardDescription>Rastreamento completo de todas as ações administrativas</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Data/Hora</TableHead>
                      <TableHead>Ação</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>IP</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {auditLogsData?.logs?.map((log: any) => (
                      <TableRow key={log.id}>
                        <TableCell>
                          {format(new Date(log.createdAt), "dd/MM/yyyy HH:mm:ss")}
                        </TableCell>
                        <TableCell className="font-medium">
                          {log.action.replace(/_/g, " ").toUpperCase()}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{log.entityType}</Badge>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {log.ipAddress}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PageContainer>
  );
}
